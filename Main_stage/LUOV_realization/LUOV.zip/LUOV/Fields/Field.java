package Fields;

public interface Field {
    
    public FieldElement addition(FieldElement a, FieldElement b);
    public FieldElement division(FieldElement a, FieldElement b);
    public FieldElement squaring(FieldElement a);//a^2
    public FieldElement multiplication(FieldElement a, FieldElement b);
    public FieldElement inversion(FieldElement a);
    public FieldElement squareRoot(FieldElement a);
    public FieldElement randomElement();
    public FieldElement zero();
    public FieldElement one();
    
}
