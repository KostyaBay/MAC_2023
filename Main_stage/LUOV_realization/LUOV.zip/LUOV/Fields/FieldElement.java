package Fields;

public interface FieldElement {
    
    public FieldElement copy();
    public boolean repEquals(FieldElement a);
    
}