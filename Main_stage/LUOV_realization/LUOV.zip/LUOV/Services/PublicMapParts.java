package Services;

import Utils.Pack;

public class PublicMapParts {
    
    private String C;
    private String L;
    private String Q1;

    public PublicMapParts(String C, String L, String Q1) {
        this.C = C;
        this.L = L;
        this.Q1 = Q1;
    }

    public String getC() {
        return C;
    }

    public String getL() {
        return L;
    }

    public String getQ1() {
        return Q1;
    }
   
    public int[][] getCMatrix(int m) {
        return Pack.unpackBin(C, m, 1);
    }

    public int[][] getLMatrix(int v, int m) {
        return Pack.unpackBin(L, m, m + v);
    }

    public int[][] getQ1Matrix(int v, int m) {
        return Pack.unpackBin(Q1, m, (v*(v + 1)/2) + (v * m));
    } 
}
