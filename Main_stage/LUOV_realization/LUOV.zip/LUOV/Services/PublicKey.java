package Services;

import java.math.BigInteger;
import Utils.Pack;
import Utils.Encoders.Hex;


public class PublicKey {
    
    private String publicSeed;
    private String Q2;

    public PublicKey(String publicSeed, String Q2) {
        this.publicSeed = publicSeed;
        this.Q2 = Q2;
    }

    public String getPublicSeed() {
        return publicSeed;
    }
    
    public String getQ2() {
        return Q2;
    }
    
    public byte[] getPublicSeedBytes() {
        return Hex.decode(publicSeed);
    }
    
    public int[][] getQ2Matrix(int m) {
        return Pack.unpackBin(Q2, m, m*(m + 1)/2);
    }
    
    @Override
    public String toString() {
        return "[" + publicSeed + ", " + (new BigInteger(Q2, 2)).toString(16) + "]";
    }
    
}

