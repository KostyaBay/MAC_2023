package Services;

import Utils.Functions;
import Utils.Pack;

public class LinearTransformation {
    
    private String T;

    public LinearTransformation(String T) {
        this.T = T;
    }

    public String getT() {
        return T;
    }
    
    public int[][] getTMatrix(int v, int m) {
        return Pack.unpackBin(T, v, m);
    }
    
    public int[][] buildLinearTransMatrix(int v, int m) {
        int[][] T_matrix = getTMatrix(v, m);
        int[][] upper = Functions.matrixColumnUnion(
                Functions.identityMatrix(v), T_matrix);
        int[][] lower = Functions.matrixColumnUnion(
                Functions.sameValueMatrix(m, v, 0), 
                Functions.identityMatrix(m));
        return Functions.matrixRowUnion(upper, lower);
    }
    
}
