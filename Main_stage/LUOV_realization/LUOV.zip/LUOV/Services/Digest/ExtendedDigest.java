package Services.Digest;

public interface ExtendedDigest 
    extends Digest
{
    public int getByteLength();
}
