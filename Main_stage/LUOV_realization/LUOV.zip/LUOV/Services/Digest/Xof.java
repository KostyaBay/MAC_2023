package Services.Digest;

public interface Xof
    extends ExtendedDigest
{
    int doFinal(byte[] out, int outOff, int outLen);

    int doOutput(byte[] out, int outOff, int outLen);
}
