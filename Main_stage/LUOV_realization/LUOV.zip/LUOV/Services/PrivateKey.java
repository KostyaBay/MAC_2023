package Services;

import Utils.Encoders.Hex;

public class PrivateKey {
    
    private final String privateSeed;

    public PrivateKey(String privateSeed) {
        this.privateSeed = privateSeed;
    }

    public String getPrivateSeed() {
        return privateSeed;
    }

    public byte[] getPrivateSeedBytes() {
        return Hex.decode(privateSeed);
    }
    
}