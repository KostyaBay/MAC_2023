package Services;

public class KeyPair {
    
    private PrivateKey privateKey;
    private PublicKey publicKey;
   
    public KeyPair(PrivateKey privateKey, PublicKey publicKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }
    public void setPrivateKey(PrivateKey privateKey) {
        this.privateKey = privateKey;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }
    
    public void setPublicKey(PublicKey publicKey) {
        this.publicKey = publicKey;
    }
    
    @Override
    public String toString() {
        return "*** KEY GENERATION TEST ***" +
                "\n- Private Key: " + privateKey.getPrivateSeed() +
                "\n- Public Key: " + publicKey.toString() + "\n";
    }
    
}
