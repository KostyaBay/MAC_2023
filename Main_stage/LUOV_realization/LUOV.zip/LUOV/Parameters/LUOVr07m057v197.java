package Parameters;

import Fields.Field207;

public class LUOVr07m057v197 extends Parameters {
    
    public LUOVr07m057v197() {
        this.r = 7;
        this.m = 57;
        this.v = 197;
        this.field = new Field207();
    }
    
}
