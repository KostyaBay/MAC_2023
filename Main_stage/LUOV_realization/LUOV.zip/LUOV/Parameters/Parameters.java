package Parameters;

import Fields.Field2n;

public abstract class Parameters {
    
    int r, m, v;
    Field2n field;
    
    public int getR() {
        return r;
    }
    
    public int getM() {
        return m;
    }
    
    public int getV() {
        return v;
    }
    
    public Field2n getField() {
        return field;
    }
    
}
