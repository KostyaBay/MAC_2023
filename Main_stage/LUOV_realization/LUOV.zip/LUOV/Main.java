import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

import Parameters.*;
import Services.*;
public class Main {
    
    public static void main(String[] args) throws Exception {
        
        int k = 1;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("\nSelect parameters:\n");
        System.out.print("1. GF(207): r=7,m=57,v=197\n");
        System.out.print("2. GF(261): r=61,m=60,v=261\n");
        System.out.print("Your answer: 2");
        //Scanner in = new Scanner(System.in);
        //k = in.nextInt();
        
        switch (k) {
            case 1:
                Parameters params = new LUOVr07m057v197();
                System.out.println("\nr = " + params.getR() + "; m = " + params.getM() + "; v = " + params.getV() + "\n\n");
                
                LUOV luov1 = new LUOV(params);
                luov1.printKeyPair();

                //System.out.print("- Message to be Signed: ");
                //String messageToBeSigned = br.readLine();
                
                String messageToBeSigned = "OBYtSkfMlAx4dFFX0eidQuj7XMCa3zmfLkpBNazkGkSTHaNGpub35r3Dl58D7DIishLzW5p3oWdqe9BCAy3UZXIJ48p57JSDnAMNUwY7ItzQKGuRvtIxUbBfELmJAJsSrbqsieRDQ7YQf1zI2eHoqChcx6esRHyeRQIU08uBNLjDnsvUXQk3wIeVeDtt3wUkL1HL6zFli0HHl9qU6dpnv3vUcmKXOKmjyDA9XdI3iD5247OawAfQjhoDflA1gQfvjiGHH8cVtNLqWS0wMByunJRQjU7js1VtTy4AavO3b3wFjQgm8Ljc4xJ0E118rrqhb45JdCfuY4n6eUVNlakcuAEoeimcyBxbK9NNC7JxsQBmb5bkgYC09nNfZfV57gU9g22LKYC6g0MrZhK0wjVHW6p0pNZxg96TpP1tQBSOo3BnM3Ph9WW4i39LVU8KXIE5NU2GTf0xl3asOKo08OowBmgVwCjnvFNIPq9hw9MMllKdB3U7YngaqFpF7ZCa7bNbsLQUU9CDeqCOgZju7tmdT91FQtiUOtGQ6GPdhh3MjaWphfjw6KEL2djvmRuUCMI4HitAOyuev1uNVxcIiU8Ci776E8u7cc5RqjovlkDglCa4pJkXOrR7mug1SjilC6AiQ7Y62Efr1nhhL7ACkzpItJfRDNutXv6TOOhakyQ2O7El9ojxmTBXZNy5kKGYDwYfBLudUn9uXZ1YZh8StNrbrqhxlQcCNgTHFFMuv95Q46E20BV1Z9NdwPoBwo90oQozZyAuYdN5DBELYfLf73ONJOfrzQ6tuGXCxNQX19P0qhXoG3XZ54MNextvf1Zvq6YApMULv9nABlcIxUtKNG2sEOrVK8ZiNakj53w1k9RmxkceQ2lERepx7mZhXff9ralzoMLqkMXu329sBqruV6iH40fmzamm8l3LqF9m5Mrpa96h6XrnQkCsEx117WoZbtoFxFVg4VeTgkmA0HDGUblCRbb2zWl0N6XbbV5sT0I5PFsh0MELoig5wo9ihM9meoFh10QwhYYhGanJ9DPf2IW1YFo1QU2ZuPgbmpRqyYBniPUz00aGXShKpy70wO3d4W4kcSAi645eIcw3VWD0RHpAiIflsE4uwTwEA4gOQ8k6BHdG2OrI5T6OVfTeonh4czxdHtlXGow8NVuiRcyUWvACJwOhZb0jSFao0RW8FyK8iLS6inSE97QbVMT6PJ5XqdaWZKKSp1oXtnxibsRLZDCRngWNLPTDWMfRYa622xoE4woWV0VxGJg0ZH925chMSzbjJy4pRzhN0b4vNqRVyRrTe78Z99ZJHCXcCu7GKmSYSg918UkBqUIgxv8kOsVatX4aiNqQl8tqR9o6LBg3KgFa3ZFq6cVlncWhFVCUlRdlPodQuZaAX3vwfAfUZgI7aWA0T4c6lv8iQoDhWOis39uz4objWXcI5dYcCY7dqOcwU3S3m8KJwB053bmhCgc2GgkKNkAYOtq5IiTjjgGoorIYMJnUkudcqXyf0HxBYryWtjKMJmEzthI4zCeI6rGdeQBkX5YwSlCvKMwAa6O9y0UtNqD8l0x46BuartaCivs4QtoXCHZTgYM019OLHvmsjmFg5gZCutgBLPboB6zOEpLap0Gv5EAj5AUXNYzKLfDNKm9UqbE1VQ3VM7JwZZckuLOHH5UfUrGFMERBensfahqNIY4RRGnYMBX19tH2wMlAMPMDdJJ8LzLYjlQdP82HisVkUyxwmdMmfGAkerC6DnVlN9S9C0jqljCiFMIyUJXDp8DAJ3XgpDUY3Oy9OAA0S3M8ltHYl1i7hSaYClm4oV2TYvK0F7mW1rLW6SQWBXbedtzb3045Szv7mSicFpZ1QWujleD6depQ5VmuJnVPpDOh1Zkuy7g6rLq8l4ebEP3hIcDWmrITF5NutLWgnpVm5lO8ybbtspglQ74b2pJOiS9lf6AGIx8bMn0aS7dqqATVTLXkbcbU5tw6PoP5u2wUoVNMQHQAvClGsZ19b7v9qMo2I3U8a9XPm4ViO5nnhTl9m8S9wVgr2XlSzP1JzNuMOQNBTGjRIWFgxgGOy3mQKMyPolVtvF5S2KvqkjvCgNSZChnVC9xeAjrZ4hpxgDdLOPoWGRSPhZs0MC87uhSMDJOcIT6k5zRYR67DQmIS6F5LM9wRwfFX0OmeRJjhckeBfewuNxQnCwDFo3hlUoktIPqamowy5phcS0dNeKl8nxYSh3XJLSORhR9nvruQ3zbwTZjEeEJkwFkwY5UzCGamRr80QlUJceJMQsrunKgDHJHIiBVqgMiVKlaKOg22IzrjGBqYuUwIPkCwz2MbUfIAao4JzT773bxBdVpjrzi0LjKjSqadQsNijYe618WK0RprC4DH5iDyilLpoENjWXvuROD9YqR4GYvPeXq5kSeHPevPy78kbGWafGrzBs3NNIyCpMLuT3JjVG9vaytroIzlRPOvv9nIDkfgtykMwE6SztbgtsSgpz53u53URfNGUNgp04MKd3RsXqZ1Kf7Y4eZfdWIJO4W2qLDZ2hmDGnslPVpp0BjCwUeoUsMlZSWdkwxyGt5LJl1xPbJP2eR4CQyEIqZ8Fz898ZYYdg8OAp481ZnQ8jmUieK3LgJH1SuwoqVuIRY7tNbqao1s7CzY4PmJb6ACS65bFQkZce715H63fOdLhONA9VSlVDaX30TW2GFjk1rMrHDxbU2TRgNMoyAarPXhBf6GznOEyYxEs2Uk7I76Ure8qEUza0VOL8J5mJrCDQjXQmDSUD7vBOSR0N8Evoue9AgGtiHomnSyocHPCU4xxq8Ku8cYTrVJW1azDdo5W8ykVBfs5Pti3B7YV6nVYRTJAyBs99CbgYvfGjWvz0KIXk13a1M0qnXogc2RIY4taof88okZ8arJyIYimp6RTbfxR3qSzX8kIAZIxE6WmwpgvjIfw6fLW6kDqAUjWnuy3jy9AdsKk6wjxIfawknxKA3RD08LVg11KKo9uQX8JkzRnGCnJniXMJYOIGsRTggLW4kGeRVrx0JdibkAkPYoCLdyudarRx5YdymZNVw0kcmvJa40ebHay01EgZeaxUQevsqAzEhiLXQl1UsyQuFDbmFwVLQC6blYzQWtHeciMCoeO9xdwZTaPK4gYMP4888htvod8rljarEPZbWc5MMKErAPSlLAqJmHNt6v3mx6hTsIJnQ4o85a7m3jE6SSPacR6J7NMJpjrJGhWYK9UJl6Uirdwm7noS7mzMg4oLURqnLQirX3TVmlHBLgbHnAGHJIEO4rNxK2wIOl9UFosOkirfOKVsyVI1mFUxMwMsyrBdXSzh1oR9zb1gzHAgVV4Xue5v7QVEikN4trmSizPsNq6JS9b3NNLOqhWY32pPBON9iO7QzT80qWXd5Dd8hyU48kDCxrCi3HHq1y5dakrrLi3hpXjcGYYJgJ73uur5LOlttcWKqsdkEHLvP49GZYN6wrcsWTUqtG5je7uChHI6kvZORbfCGkvJhDYxeUhRMvVIQwBYUamtaOQqsPdZyfH2JPD1bndFWkpgU54xR1VdPo5mmbvNsQnjN1grY4dcy4LpiBqyBq3WPkGJHaksFbH3vywjlsBNbtnIoB3p0jrhKigQlWAMWUIUg1Lwh4XUUkWlat4s4pTY9727WyODqYodU6yBj0bkgKN6PgSRWQcGnOCs07YB13JT0I8sGZGBsZasKwpCquZ1lMXFGzAcCIzpypygzUOdbSY12D3ZAri4LF5Q4bzUYQqBXBi1GlJMvE38nc6raey2ZKJesX7wt8JbZ9o5IG9lWDw5j9vRU23Gy0J4ex4Kki5TG3UqXYmLrH2n9BGQDrJt7yDnlJ9t9AA7dcoSinwB2KNHX77tKNTFqBESbRCoQeiAEav681Owfo62ZcvVOvqar666wNndYD1UEaWQKpxGrVnteiCStToYQcbh2mOh0TQl1b3U7TebHyWdpSbyrNuzLEnl7EbBiJWTvfcTTVCOMMJRiM9Uj9khJswxMdlR694XAEbHYRIskZgDQKMCuRazahYKXETFIyYGh5cKEwXcHPdkbjalk7ggI8AZLCeYVzJvF6LBEAd18B1ryJlF2QuN3L6WsteS8XAo178fjUdCXtIV0x2LDLbCSroSTIcS4pXXC8X6hc8Sl0acEyqyHikyKcqTw0ovhQWOXIIQwYix26vVqA479QJR6Cdx7ospJzgfb7TeHQNix90cfaT4SndhbVjjMVvDF5UsMcSrQ0Pkxd6Q6P6Ni8ex4CsapuZeXDq4v6tbBjqA8phe989dqIeKpGgDj2co0SYoufQnokomZkVirIEmQUZBxgRnJYJe9DZqzJV5pXjWdCayu2ImfLTFWvA1SEL0eIZBGRkm3JNh9xhgVBC11uLgiWRq9Zlf59Q0UxYXe16XlVd7gZKhUaMYKOSdPcmRJslthHVwqAJznoJuqgJ0iYaLKA1QmaHsyNAAGHTSfQyjY9lfR2kFwOAoTJqboXOm6mArvKq4hFq9SloX2DCf1H7KV0VwJWiP1PUOSxtda0cqXP5NX5CQkAawxXL3DiiQT1RbF9HgSlqsZbmr09k3NczsZg2eLi2arAkD95VxXbSa7MlxmGgQOk8YLLNWGTulUVFgf6iBSYYI4MB1zqNPwqSRq5o79L3a4kRSKcvvGIyiroCaugSxm08K6Fj8TcW4r8IJsaC905rDFNxhwJH4VnWNfpguFECR1OYxhi90QkwvPnrCjpJuoXGLv3IR9ucRk9vYAzs7MfKXfnlrccnREQkyckzeOk2xq4ZJwVGWTw7D7gD5vw6GebXOswY1EffeFUKrXSYkyyXNisuCDgTadz4k3641ZCdJ67RUKtgrFY6RVycHpCeCGByaJmUlgOVtImTH6yyrlkooigPiRfd5cZ5EOWwPRmfrR8lOrPXzHyG8PsSOBc2hGgrGG5dPInHKm1NoY3KhF1EFoBVRNGEUfMiDYSV3W6AObK1YI3XK5jOYekoCIl89Y8rv1dQUvtt5IcnFUnwjY97KhngvzKzcJ9IXvEEqwheURrnttukgW0T6vAifXYHzY6vm5c2ZMzpDzgyevy1zrseChFuPTLMLOOdzDggENmY7Kp9iGVIkRyYJlWjyjA49sRX5FNJltpD3ZmSMUY9VeIHCkTE6HtdPYowL3yVJiKn7nCLcObzvVwxG9YLwL5C9l380jqZ0aU7WPvjcITrpxmx1lWqHLibdQ7xMVgwPVz9AOpwci2VGmPhBpzyOaQqs7Fcv8YuQYNCG5TtHwndkMwPjYeRlYQ6SciM1P9768XizLlWY6GZghIhXSr0IKVCOCMPX2ofACQcQ5leQ91DE2ipDD1c6Nd7WuZGcJUdRZR6BnuNTTG5cQQNLyZURN1KjDwhtJF4YTVuD9m3MCIG2Pb4nC0ygRpiYRbvZMVQsCINiYNhyH6IpETqS9orZOqzB8yMXMzvExpGp26sFqi5zbmUv35DOs78wYKg10VVylq5ZmqvStQZWVhALUtBedkcrlJWBMSjGs1ZfJmmZCYGl1LBHkJjtPrJHLNQVnBy2k6DW0NMDBKXs0iKUjGRBFbHhD6urnYeX8m1BqoCbp4hU2EARTbc1O7w56x2ox07U6wX0JLil2nzDMRuAp1eai1Vu2mWxMuPrCj7OmEY0mME5zKS7Jnf8yUK8DWYuIqdH7SjuKMZ1SOjbc4QQ9H55xs9NcZxKfNEM8gvKZke6rg0nT4Dc9DPhwdbBo6oNXH4lSyrREZ9ryfigPa5KfeiP9IstRVegDunbuKhZIVbJPUhSBx3H9U17kbBtAJ2orhJPLphXbiahSiFpiO4j67gmSbHsXNMklL1l74A4FqbKVncKYL89JJ8a0jFfIE4Y62WtpqrnOF6jG47tOYDhc0bK01pD0KGUP62h2WPLVYQtW3KjkDw7w8FSZb4Q2rtxUqfe0m5S3cxNcGQEbb0smMQCu7c4SX1IeWZ7vFNbtaxIuJAQTxDFCPqGqmpIVg4Kepss0SFGVXULlPmT0LSqR1cl2vzjlNRKnIcPO9jdeG1xcbl2FU9sMymzizekNxZb3p70pBZjNzJAZ6gmpvlqC4oLcGpFv6WFFpTquN9TlJ1aHBHgZt8Dd1PXxgrlQgoO9drR8MvCVK4lbyaFDZUfmb3E6zlx8Kt9TT0i6RJJDuSPDYcxOFcEt2CgCIB3tACnYrN71ivA8GkLi15NvhQa11j3XI6MS54V44ubp4V6URePlOZbPXnoIsuxlc8LcgU5jnuyPDMNQLuLadgbyFDoEVqDTwMuoXZkrJ7faZCD0q1gNqiaK490Z0tMbQ9VnQFmXXwjAcSJemdb88L63FIHDUy3sLe24EI5iyopv7xwqUH7hZemVQWiLns9NN1f1aEOqxpw5WhHNjT7jufUiWk4cTIDhUf5cO0UdVkndUX9OfQXq93EPkqXuLFDg7o0uBXsgaFDNoqX76ZYlW7GgTUAls1WQ1oZQm73Wej6P1fcoWjSCesSwCyXXMPUHf7u4MirgoO2q05gKNb8cCqgxHcilh6D586ll7fZRIwtqWkWWv1XwTtHDoktSiEhLHGaWBaFdCdS0VOVFXeFklPYkB30hCgK0sQJNsiM0Y894i6BPCV7BBxYm6f4k6CKVr4v26c43fy3oHiHHtwwjcKnr1sMFxzh8QPs0QdsUJ52qBU36DrSLQ3MmlCekUWN85qs4kI7JhxGxCVXB9L1p4D8uL8izszpziU4kLfzTGspMf9Fjt5GGu7BZCFEqY0w67rX6wFfolFLci68OoCo7eTpy6ckxCp38JmJWmymwJaPiYWDGWPbCl2hzKBiz2UzpNRvHhRjnuj9wGmhZ1Hwnslmp6CWkDJNURwwaSpsOylgC1sosLvPUMCNhTTjyxBsCMuwshZ4dVQ1GI5pfQdxsQcmmPPJTlirxnCYNA8Re6sw0tM3tfvHa6CfslP2Qogb9N2i9ZD1CbO1OtQ7WqqzkiCvzCWyQuypG5GAMAw8zAfc3cvESXGrVb7H44AUhxry91PUwooVaSdK8JbhHPeDhNrfgQjYq5tDkWgpAOeAKZUbnWHThk40lq134HWwNL2UjuB0NVwG2ukM90aUeqkaFWXsaR47yvrD4Xf2pRQHthwwhFY5zUNY7uJFMXyjoAtDfp56411SHgmyjlsJF18d7uifj4LgM3e4paVXcNiTFjLixRxt07Muk6bfCopcJWErjVyZz1PSa20cwTHv89pSoiouC1E1vC0ys8HEzU0fFZ7E6g7vLj0SpjZ9xFydwt4PZZ59WlviZiDdUxvEZP9oUT2rTdBmMQ9qf1NJxsP4WCYflNvFrLJAeldsSgsOlIa6aTFU28qaBbyIegX7dW1i6TSyfZnRY02tZaudYzO37BMcuavhZVS0LAuibotrFRYbEDLRbcEXoxGmyqjAknnR3oWkulAF9lJpIVBQZBXVVxVjxJNAv8jUTL7U4yqe9lHI1uTvjGC8H50NIfp6y990kggbDtOl4dfemG6ofWY9vQeBQXr7OXYMmx6w0L5zB7CzZjG8UdjMU8G7LITeCzKqFONWNcZpMTuQLY4Uy0edxwwuRZSzjFDVEbI3Tml9C3HXK8Xe0qcCnHKvKHs6AlzXilTygNHUvmzFUF7SZvGT33j8YkGbg4dFFgDmdYoWMvy75Ba1OzlEmiUUjoL3J0QbggOQB3RYyVmwZzdNCeRV2DcHc42vN8t3I8HT4MAmNZ9aLxT4HFJQMFWTryApUgaGSK0qqvgI0Qcv2GLpu1MgquNASeB14VBDASszGFYw8PklLUB3TpALo8gOsx0H21yDBpZVciYhyVN7sSNFqH6wW9keSRTVuPEBrenAIj7H474yGmPqcRsA4LAcsnmHZT5tnRK2j09x7ffeK43ynobNRSlJsjfVxUddNOEC2AALG1ZGl8g9RivZN5xkffWpKNrssI6L9oUwWNIHiMRQQi6DBtx9Aa4tznCSdbGpwweYgk203nRvO4N7itD9Q2cJlXLHd21q8IsH6UXvDNMXYNZyhYdimYclJ0fyPFLTgrUij5sF2L77i2PrJ1yxJobTrJMkkfIYmSjhPteeZsiXNaq4LvY0Y6P98QuOMOZ154UJx69lXdH8sgEKZadNnLbyW8luOgd0NqzgVouaeQrh16uZB2EW1HUZ28Oqno0UO2kRT2kDpUyETE3Jhc9KViNnKSaVIADQMvvODbIjViHd9NAdGwxb9o673LZdHKGOXdU8W0Wu6vMTfs5M7qzbsDe4RS4DTQ87iW0ojcNcTfVjGpqpPhkxXFWkzpdMLZzNvlMWKcouIPbYOZ0MCzFQxQMCvTHyxAzjYntfl5UcsDpZHEM3tTnZ1jJEKhuCZangZtEBa5qJaSNS2jIova8EEg7euWVdkDXNEWLF5KJAdh0rYJj8n1DdFd17ndRSAqdIiDlEVtQQuxvcAxloJP6zjVr5gLwr3WYBZcpXwF6V9Vx84F47VD10Ch6vKKOywTxh8LOTySGlY2YaEwrD9pNr5Q9Iihvmh3YGUc2I8c4Qt8vkzepCPxpFSoLa4MAVrlRla6y4HkzcYwJujKWHkV4I9MU81cDh6XUCRG0boMgeiGFxRCRMOpqOmyDUR8Oxa81hzmzsmcj1GaQ6yiZZeG3pPvxIkT2K7KedSE2mqzfzG2M28lLM5mFl0JgPitThX8v3yVNFvTErMcbri5JzheiZisKWurrFBVOtyLtXkkUXFeABnkhEGm8cyAt8K9rkHwtTuoCSr2miaw2rtPMsQyLWUyES3jmsxy4r9jMLh1KiexHJ9ee8HNDWBFP1lavu61HaTvbbjuvZw6qUtgVR2C4CwWwDn1lnjqHZswj8s87G4l0doeWqrZzJ4MiZCDrjkprZ5r2yWskCSq9b18VisTGwoeZKnTC1bfCuKFZdRPFI2cbmQReL2JmY5Xnb9s0m7jrdqYdAVTXQxTUgeb9oIOTJXCAiqfupQd6EbaMqxHXyVEbl00xwh7vnBAQwQ9UxsGCi4t1YrBLA02fdiZYLlP2RTUxL3sEXgTs9mfqunLlAV2mGl9i3hMRtwlwMlvnirIJZYTvbyIjItFBhiM2jC0jms33saZ0gDeeunuuYirW07uyPeafVE61xKan0JXgfBIMwCFzynYsC8ar6eGEe4VfXSusJeKVEvUiz3WxbFlqEIhw94le4F36drIZzHqUiqM89AoDzvHVIzQ22WdRuh7NOKGZbHc4CZsdCLP5Pfu30dpa20dYVl2ZJ56BHUH3UOpIHWm9lPDZCsIcTm2twyaG2sRK55syU0XM7FE1TrOcj3aTkaXQpVlULfMNvkKUyzY70i9ps4ectBP8HSkAl0flcLCao2kcrjN9nO1ZHNFy6PoizYwR9M5EBv0wAb5VnaMuQ3RL0Ad678bjJHtpl1Rn5pMmXJTONGq9ltxi0yLadKVm6tTl5pDyduCC9RIh3KhWRXtFNZZimEKKufcGJp9WkGzJvc8uTR8mpqGTjuLEYiryH9Xc7WukbKk5do4fcn3W6Pbm2mg3U2WrlEqWMTaP5yRt5mdQjMoe1YBiGMAo8GqduDXIl0h8DTaLXXzjgmJ6F1GYqnz24OLO3lSo9SDvx8xJAVKLWoZcNkUIC3zqCGjJrBAnCK8y1Wz0PxWHWHzZLOUvYqMjj1N2x5LYi4DEUhMdPRBEcd8pHVYGAUfnPMU4Cg3ejvSuZ1ZXI9wbwBTzHOpSux02PJzlD9x8rrcVuh1qfXK8uUiO0hmlbWJU5JehJtQd7e0kRhBnhipRvIFKTL6nT6bbPCbONvvUG7QlZkIz8w9nuPb5hegYKpOxT5LbvSGse3GOJFaotBwLcSMm5GGE6rX5ejNvWpI9a0ghNoRGyxtiG8BQZVpUW85xHvy4ATAlOCooTJ6WOM1qkMteLXCGfNAACi0YyiCIBnF5RbzW2vz6XfcOycgPmBXztXyb7k485sQLPMue31aH7z6rGsEKi0TiGJ1uhX3qNdnafPPuIfL15QdTlPn3wfsgqziuXXfYEZfkV1IguR4ZoUqlxteLBWq9XJYDMIQ1v6c";
                long begin =  System.currentTimeMillis();
                
                Signature sign = luov1.sign(messageToBeSigned.getBytes());
                
                long end = System.currentTimeMillis();
                System.out.println((double)(end - begin));

                //System.out.print("- Message to be Verified: ");
                //String messageToBeVerified = br.readLine();

                //System.out.println("- Valid Message Signature: " + 
                //luov1.verify(luov1.publicKey, messageToBeVerified.getBytes(), sign));
        
                break;
        
            case 2:
                params = new LUOVr61m060v261();
                System.out.println("\nr = " + params.getR() + "; m = " + params.getM() + "; v = " + params.getV() + "\n\n");
                
                LUOV luov2 = new LUOV(params);
                luov2.printKeyPair();

                System.out.print("- Message to be Signed: ");
                String messageToBeSigned2 = br.readLine();
                
                Signature sign2 = luov2.sign(messageToBeSigned2.getBytes());
                System.out.println(sign2);

                System.out.print("- Message to be Verified: ");
                String messageToBeVerified2 = br.readLine();

                System.out.println("- Valid Message Signature: " + 
                luov2.verify(luov2.publicKey, messageToBeVerified2.getBytes(), sign2));
                break;
        }
        

    }
    
}